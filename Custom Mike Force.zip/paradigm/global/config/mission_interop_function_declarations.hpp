//Declare functions that are used for interop between paradigm and the mission here.
//These are loaded from the ParadigmInteropFunctions class in the missionConfigFile
class ParadigmInteropFunctionDeclarations
{
	test_interop = "";
	get_squad_composition = "";
	harass_filter_target_players = "";
	harass_get_enemy_side = "";
	valid_attack_angles = "";
};