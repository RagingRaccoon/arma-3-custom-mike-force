# Paradigm

Paradigm is a library that can be either inserted into a mission or installed as a mod. 
It provides a variety of nearly plug-and-play features for use in custom missions, as well as utility functions to speed up mission development.

## IMPORTANT LICENSING INFORMATION

We're still finalising the license under which this code can be modified and redistributed. 
Until the new license is published, you can modify this work under the original license within this repository, further to the conditions stated here: https://community.sogpf.com/d/198-modifying-mike-force.

## IMPORTANT BUILD INFORMATION

We're in the process of updating our documentation for Paradigm.
For usage instructions, see https://github.com/Savage-Game-Design/Mike-Force.


