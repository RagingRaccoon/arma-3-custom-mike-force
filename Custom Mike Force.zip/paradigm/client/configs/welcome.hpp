class ParaWelcomeScreen {
    version = "v0.00.0000";

    class Welcome {
        title = "Welcome to Mike Force";
        content = "Structured Text Content";
    };

    class Changelog {
        title = "Mike Force - Changelog";
        content = "<t color='#ffffff'>Changelogs</t><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>Hi";
    };
};