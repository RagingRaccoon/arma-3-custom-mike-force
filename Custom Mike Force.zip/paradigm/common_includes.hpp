#ifndef PARA_COMMON_INCLUDES
#define PARA_COMMON_INCLUDES

#define CONCAT_2(a,b) a##b
#define CONCAT_3(a,b,c) a##b##c
#define QUOTE(s) #s

#endif
