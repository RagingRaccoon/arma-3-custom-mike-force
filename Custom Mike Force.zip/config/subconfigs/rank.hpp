ranks[] =
{
	{
		{"\a3\ui_f\data\gui\cfg\ranks\private_pr.paa","Private", 0}	// rank 0 (icon, rank, pointsneeded)
	},
	{
		{"\a3\ui_f\data\gui\cfg\ranks\corporal_pr.paa","Corporal", 30}	// rank 1
	},
	{
		{"\a3\ui_f\data\gui\cfg\ranks\sergeant_pr.paa","Sergeant", 60}	// rank 2
	},
	{
		{"\a3\ui_f\data\gui\cfg\ranks\lieutenant_pr.paa","Lieutenant", 90}	// rank 3
	},
	{
		{"\a3\ui_f\data\gui\cfg\ranks\captain_pr.paa","Captain", 120}	// rank 4
	},
	{
		{"\a3\ui_f\data\gui\cfg\ranks\major_pr.paa","Major", 150}		// rank 5
	},
	{
		{"\a3\ui_f\data\gui\cfg\ranks\colonel_pr.paa","Colonel", 180}	// rank 6
	}
};
