class arsenalcleanup
{
	fnc = "vn_mf_fnc_arsenal_trash_cleanup";
};
class change_spawn_point_vehicle
{
	fnc = "vn_mf_fnc_veh_asset_handle_change_vehicle_request";
};
class changeteam
{
	fnc = "vn_mf_fnc_changeteam";
};
class eatdrink
{
	fnc = "vn_mf_fnc_eatdrink";
};
class packageforslingloading
{
	fnc = "vn_mf_fnc_packageforslingloading";
};
class settrait
{
	fnc = "vn_mf_fnc_settrait";
};
class supplyrequest
{
	fnc = "vn_mf_fnc_supplyrequest";
};
class supporttaskcreate
{
	fnc = "vn_mf_fnc_supporttaskcreate";
};
class teleport
{
	fnc = "vn_mf_fnc_teleport";
};
