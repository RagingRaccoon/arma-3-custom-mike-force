images[] =
{
	"\vn\objects_f_vietnam\civ\signs\data\billboards\vn_ui_billboard_01_ca.paa",
	"\vn\objects_f_vietnam\civ\signs\data\billboards\vn_ui_billboard_02_ca.paa",
	"\vn\objects_f_vietnam\civ\signs\data\billboards\vn_ui_billboard_03_ca.paa"
};
