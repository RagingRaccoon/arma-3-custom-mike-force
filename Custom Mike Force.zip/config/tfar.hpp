class TFAR
{
	radio_channel_name = "";
	radio_channel_password = "";
};