#include "ui\ui_main.hpp"

class RscTitles : ParadigmRscTitles 
{
	// Overlays
	#include "ui\timerOverlay\overlay.hpp"
};